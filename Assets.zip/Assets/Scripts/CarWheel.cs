
using System;
using UnityEngine;

[Serializable]
public struct CarWheel
{
	public WheelCollider collider;
	public Transform shape;
	public AudioSource skidAudio;

	public bool driveWheel;
	public bool brakesWheel;
	public bool handBrakesWheel;
	public float skidAmount;
	public float BrakesOverwriter;
	[Range(-1, 1)] public float thrutleOverwriter;
	[Range(-1, 1)] public float steerEffect;
	[Space, Header("Debug:")]
	public float torque;
	public float rpm;
	public float speed;
	public float brakes;
	public float steer;
}