using UnityEngine;

public class Aerodynamics : MonoBehaviour
{
	public float downforceCoefficient = 1000f;
	public float minimumSpeed = 10f;
	private Rigidbody rb;

	void Start()
	{
		rb = GetComponent<Rigidbody>();
	}

	void FixedUpdate()
	{
		float speed = rb.velocity.magnitude;
		if (speed > minimumSpeed)
		{
			Vector3 downforce = transform.up * (speed * -downforceCoefficient);
			rb.AddForce(downforce);
		}
	}
}
