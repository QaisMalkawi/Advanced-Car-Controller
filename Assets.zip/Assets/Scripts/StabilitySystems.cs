using UnityEngine;

public class StabilitySystems : MonoBehaviour
{
	CarController cc;

	CarWheel[] wheels;
	[SerializeField] float slipThreshold = 0.3f;

	Rigidbody rb;

	private void Start()
	{
		cc = transform.root.GetComponentInChildren<CarController>();
		rb = transform.root.GetComponentInChildren<Rigidbody>();
		wheels = cc.wheels;
		
	}
	private void FixedUpdate()
	{
		if (cc.specs.ADS)
		{
			Vector3 carForward = transform.forward;
			float dotProduct = Vector3.Dot(rb.velocity, carForward);

			if (dotProduct < 0)
			{
				rb.AddForce(-carForward * cc.specs.driftCorrectionForce);
			}
		}

		for (int i = 0; i < wheels.Length; i++)
		{
			WheelHit hit;
			wheels[i].collider.GetGroundHit(out hit);
			float slipRatio = hit.forwardSlip;
			float sidewaySlipRatio = hit.sidewaysSlip;

			wheels[i].BrakesOverwriter = 0f;
			if (Mathf.Abs(sidewaySlipRatio) > slipThreshold)
			{
				if (cc.specs.SCS)
				{
					float brakeCorrectionForce = sidewaySlipRatio * cc.specs.brakeCorrection;
					wheels[i].BrakesOverwriter = Mathf.Abs(brakeCorrectionForce);
				}
			}
			if (Mathf.Abs(slipRatio) > slipThreshold)
			{
				if (cc.specs.TCS)
				{
					float slipCorrectionForce = slipRatio * cc.specs.slipCorrection;
					wheels[i].thrutleOverwriter -= Mathf.Abs(slipCorrectionForce / cc.specs.maxTorque);
				}
				else
				{
					wheels[i].thrutleOverwriter = 1f;
				}
			}
			else
			{
				wheels[i].thrutleOverwriter = 1f;
			}
		}
	}
}