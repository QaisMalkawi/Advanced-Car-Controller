using System.Collections;
using UnityEngine;
using UnityEngine.Rendering;

public class CarSound : MonoBehaviour
{
	[SerializeField] Vector2 motorPitchRange;
	[SerializeField] AudioSource engineSound;
	[SerializeField] AudioSource collisionSound;
	[SerializeField] AudioClip[] gearShiftClips;
	[SerializeField] AudioClip[] collisionClips;

	[SerializeField, Range(0, 1)] float driftThreshold = 0.25f;
	CarWheel[] wheels;

	bool shifting;
	float valueToDropTo;

	CarController cc;
	private void Start()
	{
		cc = transform.root.GetComponentInChildren<CarController>();
		// Get the WheelCollider components on the car
		wheels = cc.wheels;
		cc.GearShifted.AddListener(GearShifted);
	}
	private void OnCollisionEnter(Collision collision)
	{
		Debug.Log("Collision");
		collisionSound.PlayOneShot(collisionClips[Random.Range(0, collisionClips.Length - 1)]);
	}
	private void Update()
	{
		// Get the average speed of the wheels
		float speed = 0f;
		for (int i= 0; i < wheels.Length; i++)
		{
			if (!wheels[i].driveWheel && speed == 0f)
			{
				speed = wheels[i].collider.radius * wheels[i].collider.rpm * Mathf.PI * 0.12f;
			}

			if (wheels[i].skidAmount >= driftThreshold)
			{
				wheels[i].skidAudio.volume = Mathf.Lerp(wheels[i].skidAudio.volume, wheels[i].skidAmount, 5f * Time.deltaTime);
			}
			else
			{
				wheels[i].skidAudio.volume = 0;
			}
		}

		if (!shifting)
		{
			float lerp = (speed / cc.GetMaxSpeed());
			if(cc.curGear == 0)
				lerp = cc.GetThrutle();

			// Set the pitch of the engine sound based on the car's speed
			engineSound.pitch = Mathf.Lerp(engineSound.pitch, 
											Mathf.Lerp(motorPitchRange.x,
												motorPitchRange.y,
												lerp),
											5f * Time.smoothDeltaTime);
		}
		else
		{
			engineSound.pitch = Mathf.Lerp(engineSound.pitch, valueToDropTo, Time.smoothDeltaTime * 5f);
			if (engineSound.pitch - valueToDropTo <= 0.1f)
			{
				shifting = false;
			}
		}
	}

	private void GearShifted()
	{
		shifting = true;
		valueToDropTo = (engineSound.pitch + motorPitchRange.x) / 2f;
	}
}
