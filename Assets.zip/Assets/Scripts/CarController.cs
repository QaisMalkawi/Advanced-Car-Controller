using System;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.InputSystem;



[Serializable] public struct Gear
{
	public float gearRatio;
	public int gearSpeed;
}
[Serializable] public struct CarSpecs
{
	public float maxTorque;
	public AnimationCurve torqueCurve;
	public Gear[] gears;
	public float brakeForce;
	public float steeringSpeed;
	public float maxSteerAngle;
	public float wheelbase;
	[Space]
	public bool ARS;
	public int antiRoll;
	[Space]
	public bool TCS;
	public float slipCorrection;
	[Space]
	public bool SCS;
	public float brakeCorrection;
	[Space]
	public bool ADS;
	public float driftCorrectionForce;
	[Space]
	public bool Automatic;
}

public class CarController : MonoBehaviour
{
	public CarWheel[] wheels;
	public CarSpecs specs;
	[SerializeField] Transform com;


	AntiRoll[] bars;
	float throuttle;
    float brake;
    float handBrake;
	float steerValue, actualSteer;
	public int curGear = 0;
	Rigidbody rb;
	int drivingWheels;
	public UnityEvent GearShifted;


	void Start()
    {
		bars = FindObjectsOfType<AntiRoll>();
		rb = GetComponent<Rigidbody>();
		foreach(AntiRoll bar in bars)
		{
			bar.SetAntiRoll(specs.antiRoll);
		}
		rb.centerOfMass = com.localPosition;

		for (int i = 0; i < wheels.Length; i++)
		{
			if (wheels[i].driveWheel) drivingWheels++;
		}
	}
	void FixedUpdate()
	{
		actualSteer = Mathf.Lerp(actualSteer, specs.maxSteerAngle * steerValue, specs.steeringSpeed * Time.deltaTime);
		if (MathF.Abs(actualSteer) < 0.05f)
			actualSteer = 0;
		for (int i = 0; i < wheels.Length; i++)
		{
			wheels[i].collider.steerAngle = actualSteer * wheels[i].steerEffect;

			wheels[i].collider.motorTorque = wheels[i].driveWheel ? GetTorqueToApply(GetBodySpeed()) * wheels[i].thrutleOverwriter :
																	wheels[i].collider.motorTorque * wheels[i].thrutleOverwriter;

			wheels[i].collider.brakeTorque = wheels[i].brakesWheel ? (specs.brakeForce * brake) + wheels[i].BrakesOverwriter :
																	 wheels[i].BrakesOverwriter;

			wheels[i].collider.brakeTorque = wheels[i].handBrakesWheel ? (specs.brakeForce * handBrake) + wheels[i].BrakesOverwriter :
																		 wheels[i].collider.brakeTorque;

			wheels[i].torque = wheels[i].collider.motorTorque;
			wheels[i].steer = wheels[i].collider.steerAngle;
			wheels[i].brakes = wheels[i].collider.brakeTorque;
			wheels[i].rpm = wheels[i].collider.rpm;
			wheels[i].speed = GetWheelSpeed(wheels[i].collider);

			if (wheels[i].collider.GetGroundHit(out WheelHit hit))
			{
				float sidewaysSlip = Mathf.Abs(hit.sidewaysSlip);

				if (sidewaysSlip > 0)
					wheels[i].skidAmount = sidewaysSlip;
				else
					wheels[i].skidAmount = 0f;
			}
			else
				wheels[i].skidAmount = 0f;
		}

		if (specs.Automatic)
		{
			for (int i = 1; i < specs.gears.Length; i++)
			{
				float cutter = (20f / throuttle);
				if(throuttle == 0)
				{
					cutter = 2f;
				}
				if (GetBodySpeed() + cutter < specs.gears[i].gearSpeed)
				{
					if (curGear + 1 == i) break;

					curGear += (i > curGear + 1) ? 1 : -1;
					GearShifted.Invoke();
					break;
				}
			}

		}
	}
	private void LateUpdate()
	{
		foreach (CarWheel wheel in wheels)
		{
			Vector3 pos;
			Quaternion rot;
			wheel.collider.GetWorldPose(out pos, out rot);

			wheel.shape.position= pos;
			wheel.shape.rotation= rot;
		}
	}
	float GetTorqueToApply(float carSpeed)
	{
		float progress = 1 - (specs.gears[curGear + 1].gearSpeed - carSpeed) / specs.gears[curGear + 1].gearSpeed;
		float tor =  throuttle * specs.maxTorque * specs.gears[curGear + 1].gearRatio * specs.torqueCurve.Evaluate(progress);
		tor = Mathf.Clamp(tor / (drivingWheels + 1), -specs.maxTorque, specs.maxTorque);
		return tor;
	}
	float GetWheelSpeed(WheelCollider wheel)
	{
		return (wheel.rpm * 2f * Mathf.PI * wheel.radius) / 60f;
	}
	float GetBodySpeed()
	{
		return rb.velocity.magnitude * 3.6f;
	}
	public float GetBrakes()
	{
		return brake;
	}
	public float GetMaxSpeed()
	{
		return specs.gears[curGear + 1].gearSpeed;
	}
	public float GetThrutle()
	{
		return throuttle;
	}
	private void OnGUI()
	{
		string transm = specs.Automatic ? "Auto" : "Manual";
		GUI.color = Color.red;
		GUI.Label(new Rect(20, 20, 1920, 1080), $"Gear: {curGear}\nSpeed: {(int)GetBodySpeed()}/{specs.gears[curGear + 1].gearSpeed} \nTransmition: {transm}");
	}
	void OnMove(InputValue value)
	{
		Vector2 val = value.Get<Vector2>();
		steerValue = val.x;
		throuttle = val.y;
	}
	void OnBrake(InputValue value)
	{
		brake = value.Get<float>();
	}
	void OnHandBrake(InputValue value)
	{
		handBrake = value.Get<float>();
	}
	void OnGear(InputValue value)
	{
		specs.Automatic = false;
		int oldGear = curGear;
		curGear += (int)(value.Get<float>());
		curGear = Mathf.Clamp(curGear, -1, specs.gears.Length - 2);
		if (oldGear != curGear) GearShifted.Invoke();
	}
	void OnChangeTransmition(InputValue value)
	{
		specs.Automatic = !specs.Automatic;
	}
}